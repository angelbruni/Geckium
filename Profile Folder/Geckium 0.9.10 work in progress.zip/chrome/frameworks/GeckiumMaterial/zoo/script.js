document.addEventListener("DOMContentLoaded", () => {
	skipToPage("main", 0)
	skipToPage("buttons", 0)
});