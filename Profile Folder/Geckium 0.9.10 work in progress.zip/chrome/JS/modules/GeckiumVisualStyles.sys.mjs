const { gkPrefUtils } = ChromeUtils.importESModule("chrome://modules/content/GeckiumUtils.sys.mjs");

let previousChoice;